
import strava_analysis.get_data.get_data as get_data

def main():
    get_data()
    print("here")




if __name__ == '__main__':
    main()